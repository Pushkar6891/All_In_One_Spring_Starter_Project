package eg00233;

public interface PaymentMethodStrategy {
	public abstract void pay(int amount);
}

package eg00127;

public interface A {
	default void m1() {
		System.out.println("Inside m1() in A");
	}
}

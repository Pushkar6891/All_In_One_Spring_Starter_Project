package eg00127;

public class B implements A {

	public void m1() {
		System.out.println("Inside m1() in B");
	}
}

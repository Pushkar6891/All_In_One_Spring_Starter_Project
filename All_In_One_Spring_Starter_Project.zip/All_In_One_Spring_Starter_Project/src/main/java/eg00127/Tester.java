package eg00127;

public class Tester {

	public static void main(String[] args) {

		A a = new B();
		a.m1();
	}

}

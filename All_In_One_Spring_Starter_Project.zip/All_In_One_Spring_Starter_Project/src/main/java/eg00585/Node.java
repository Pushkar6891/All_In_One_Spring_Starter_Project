package eg00585;

public class Node {

	int data;
	Node left;
	Node right;

}

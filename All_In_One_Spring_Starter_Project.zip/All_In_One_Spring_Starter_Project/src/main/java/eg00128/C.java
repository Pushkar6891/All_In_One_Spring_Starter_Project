package eg00128;

public class C implements A, B {
	public void m1() {
		System.out.println("Inside m1() in C");
	}
}

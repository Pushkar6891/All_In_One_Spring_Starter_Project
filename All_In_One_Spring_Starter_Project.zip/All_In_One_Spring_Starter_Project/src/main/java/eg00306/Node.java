package eg00306;

public class Node {

	int data;
	Node next;
	
}

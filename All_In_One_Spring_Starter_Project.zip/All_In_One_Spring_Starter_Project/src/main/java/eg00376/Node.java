package eg00376;

public class Node {

	int data;
	Node next;
	Node right;
	Node random;
}

package eg00582;

public class Node {
	int data;
	Node left;
	Node right;
}

package eg00307;

public class Node {

	int data;
	Node next;
	
}

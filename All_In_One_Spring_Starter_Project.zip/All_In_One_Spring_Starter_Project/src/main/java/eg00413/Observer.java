package eg00413;

public interface Observer {
	public void update(String location);
}

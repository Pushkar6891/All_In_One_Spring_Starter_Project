package eg00076;

public class App {

    public static void main(String[] args) {
        System.out.println("Synchronized Methods: ");
        WorkerMethodsSynchronized worker = new WorkerMethodsSynchronized();
        worker.main();
    }
}

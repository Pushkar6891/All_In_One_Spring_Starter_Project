package eg00327;

public class Node {

	int data;
	Node next;
	
}

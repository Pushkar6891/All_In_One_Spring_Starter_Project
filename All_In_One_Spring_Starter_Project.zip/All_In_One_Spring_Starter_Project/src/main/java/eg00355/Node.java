package eg00355;

public class Node {

	int data;
	Node next;
	Node right;
}

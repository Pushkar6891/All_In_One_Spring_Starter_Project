package eg00593;

public class Node {
	int data;
	Node left;
	Node right;
}

package eg00406;

public class IEDriver {

	public void findElement() {
		System.out.println("Find element from IEDriver");
	}

	public void clickElement() {
		System.out.println("Click element from IEDriver");
	}

}

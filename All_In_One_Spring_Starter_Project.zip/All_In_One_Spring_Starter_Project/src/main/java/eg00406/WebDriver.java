package eg00406;

public interface WebDriver {
	public void getElement();

	public void selectElement();
}
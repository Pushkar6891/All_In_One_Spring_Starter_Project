package eg00804;

public class Node {

	int data;
	Node next;
	
}

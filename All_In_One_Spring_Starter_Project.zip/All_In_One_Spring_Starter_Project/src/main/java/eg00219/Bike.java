package eg00219;

public interface Bike {
	public abstract void assembleBike();
}

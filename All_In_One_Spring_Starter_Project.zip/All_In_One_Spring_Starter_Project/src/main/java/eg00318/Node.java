package eg00318;

public class Node {

	int data;
	Node next;
	
}

package eg00407;

public interface Remote {

	public void on();

	public void off();
}

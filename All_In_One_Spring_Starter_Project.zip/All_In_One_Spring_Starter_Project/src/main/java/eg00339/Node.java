package eg00339;

public class Node {

	int data;
	Node next;
	Node right;
}

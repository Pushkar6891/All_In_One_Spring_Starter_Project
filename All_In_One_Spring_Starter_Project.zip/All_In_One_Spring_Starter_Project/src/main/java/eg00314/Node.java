package eg00314;

public class Node {

	int data;
	Node next;
	
}

package eg00322;

public class Node {

	int data;
	Node next;
	
}

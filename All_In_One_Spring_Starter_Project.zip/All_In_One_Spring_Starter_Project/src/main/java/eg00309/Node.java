package eg00309;

public class Node {

	int data;
	Node next;
	
}

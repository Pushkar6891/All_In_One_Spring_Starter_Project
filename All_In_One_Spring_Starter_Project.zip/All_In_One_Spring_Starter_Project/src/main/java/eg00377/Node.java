package eg00377;

public class Node {

	int data;
	Node next;
	Node right;
	Node random;
	Node child;
}

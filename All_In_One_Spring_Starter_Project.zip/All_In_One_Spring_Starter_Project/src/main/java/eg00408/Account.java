package eg00408;

public abstract class Account {
	public abstract float getBalance();
}

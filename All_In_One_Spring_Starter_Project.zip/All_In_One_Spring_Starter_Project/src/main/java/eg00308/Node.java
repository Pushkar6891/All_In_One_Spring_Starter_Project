package eg00308;

public class Node {

	int data;
	Node next;
	
}

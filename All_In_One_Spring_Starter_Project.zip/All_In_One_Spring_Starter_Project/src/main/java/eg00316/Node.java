package eg00316;

public class Node {

	int data;
	Node next;
	
}

package eg00218;

//Component
public interface Service {
	public abstract void service(String serviceType);
}

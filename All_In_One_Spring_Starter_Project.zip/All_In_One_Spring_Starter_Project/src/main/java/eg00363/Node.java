package eg00363;

public class Node {

	int data;
	Node next;
	Node right;
}

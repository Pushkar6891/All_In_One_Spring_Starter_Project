package eg00311;

public class Node {

	int data;
	Node next;
	
}

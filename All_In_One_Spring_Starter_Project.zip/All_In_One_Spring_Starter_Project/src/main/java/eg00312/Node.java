package eg00312;

public class Node {

	int data;
	Node next;
	
}

package eg00221;

public class Tester {

	public static void main(String[] args) {

		PaintApp paintApp = new PaintApp();
		paintApp.render(10);
	}

}

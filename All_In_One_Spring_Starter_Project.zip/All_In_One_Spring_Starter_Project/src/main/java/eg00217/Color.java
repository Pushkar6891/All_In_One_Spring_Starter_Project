package eg00217;

public interface Color {
	public abstract String fill();
}

package eg00301;

public class Node {

	int data;
	Node next;

}

package eg00349;

public class Node {

	int data;
	Node next;
	Node right;
}

package eg00371;

public class Node {

	int data;
	Node next;
	Node right;
}

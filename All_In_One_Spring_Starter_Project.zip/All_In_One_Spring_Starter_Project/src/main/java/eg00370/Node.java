package eg00370;

public class Node {

	int data;
	Node next;
	Node right;
}

package eg00588;

public class Node {
	int data;
	Node left;
	Node right;
}

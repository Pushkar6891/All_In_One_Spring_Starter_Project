package eg00336;

public class Node {

	int data;
	Node next;
	Node right;
}

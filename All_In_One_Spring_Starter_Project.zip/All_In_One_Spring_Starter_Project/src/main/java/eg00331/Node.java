package eg00331;

public class Node {

	int data;
	Node next;
	Node right;
}

package eg00323;

public class Node {

	int data;
	Node next;
	
}

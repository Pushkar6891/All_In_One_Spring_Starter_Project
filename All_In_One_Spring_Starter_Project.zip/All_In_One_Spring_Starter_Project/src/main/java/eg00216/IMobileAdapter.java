package eg00216;

public interface IMobileAdapter {
	public Volt get3Volt();
}

package eg00216;

public interface IWallSocket {
	public abstract Volt getVolts();
}

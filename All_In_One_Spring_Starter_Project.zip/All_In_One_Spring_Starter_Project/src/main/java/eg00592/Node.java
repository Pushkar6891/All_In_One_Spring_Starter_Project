package eg00592;

public class Node {
	int data;
	Node left;
	Node right;
}

package eg00340;

public class Node {

	int data;
	Node next;
	Node right;
}

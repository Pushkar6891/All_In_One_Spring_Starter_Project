package eg00557;

public class ArrayTester {

	public static void main(String[] args) {

		ArrayImpl a = new ArrayImpl();
		int arr[] = { 1, 4, 2, 6, 1, 8 };

		a.printNextLargerElements(arr);

	}
}
package eg00347;

public class Node {

	int data;
	Node next;
	Node right;
}

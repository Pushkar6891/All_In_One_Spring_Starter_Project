package eg00320;

public class Node {

	int data;
	Node next;
	
}

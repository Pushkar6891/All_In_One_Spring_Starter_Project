package eg00365;

public class Node {

	int data;
	Node next;
	Node right;
}

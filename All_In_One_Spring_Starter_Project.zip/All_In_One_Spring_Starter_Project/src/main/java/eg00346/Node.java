package eg00346;

public class Node {

	int data;
	Node next;
	Node right;
}

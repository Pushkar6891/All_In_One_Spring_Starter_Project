package eg00409;

public interface Dress {
	public void assemble();
}
package eg00226;

public interface Collection {
	public abstract Iterator getIterator();
}

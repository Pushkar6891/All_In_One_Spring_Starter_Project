package eg00587;

public class Node {
	int data;
	Node left;
	Node right;
}

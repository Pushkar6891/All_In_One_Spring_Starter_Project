package eg00235;

public interface Item {
	public double accept(ShoppingCartVisitor visitor);
}

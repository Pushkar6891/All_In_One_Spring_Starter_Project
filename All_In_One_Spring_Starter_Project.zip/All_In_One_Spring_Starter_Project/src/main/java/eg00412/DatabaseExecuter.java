package eg00412;

public interface DatabaseExecuter {
	public void executeDatabase(String query) throws Exception;
}

package eg00391;

public class Node {

	int data;
	Node next;
	Node right;
}

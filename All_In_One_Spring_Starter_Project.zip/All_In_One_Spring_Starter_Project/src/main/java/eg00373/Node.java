package eg00373;

public class Node {

	int data;
	Node next;
	Node right;
	Node random;
}

package eg00341;

public class Node {

	int data;
	Node next;
	Node right;
}

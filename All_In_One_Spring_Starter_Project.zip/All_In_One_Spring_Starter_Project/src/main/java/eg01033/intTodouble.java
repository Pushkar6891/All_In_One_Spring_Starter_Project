package eg01033;

public class intTodouble {

	public static void main(String[] args) {

		intTodouble obj = new intTodouble();
		obj.convertintTodoubleUsingDirectAssigment();
	}

	// 1. Using double d = i;
	public void convertintTodoubleUsingDirectAssigment() {
		int i = 200;
		double d = i;
		System.out.println(d);
	}

}

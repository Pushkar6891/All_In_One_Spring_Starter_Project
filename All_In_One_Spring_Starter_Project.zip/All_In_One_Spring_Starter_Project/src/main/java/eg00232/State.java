package eg00232;

public interface State {
	public abstract void doAction();
}

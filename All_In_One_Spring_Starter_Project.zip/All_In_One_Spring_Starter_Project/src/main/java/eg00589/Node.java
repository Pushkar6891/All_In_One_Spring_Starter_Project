package eg00589;

public class Node {
	int data;
	Node left;
	Node right;
}

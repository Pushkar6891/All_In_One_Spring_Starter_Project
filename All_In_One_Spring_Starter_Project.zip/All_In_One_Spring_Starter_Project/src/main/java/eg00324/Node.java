package eg00324;

public class Node {

	int data;
	Node next;
	
}

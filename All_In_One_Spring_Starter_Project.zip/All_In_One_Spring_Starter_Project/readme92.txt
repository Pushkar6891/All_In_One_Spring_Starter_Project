This file is used in example 92
This is used for file reading
and counting number of characters, number of words and number of lines